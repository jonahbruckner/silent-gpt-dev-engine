---
title: "Structuring a Scalable FastAPI Project with Background Tasks, Database Access, and Dependency Injection"
date: 2025-12-04T18:03:09.833459+00:00
tags:
  - backend
  - fastapi
  - python
original_id: q_2025_0001
source_engine: gpt-fallback
---
<!-- engine: gpt-fallback | created_at: 2025-12-04 18:02:19 UTC -->

# Structuring a Scalable FastAPI Project with Background Tasks, Database Access, and Dependency Injection

FastAPI has rapidly become a go-to framework for building modern, high-performance APIs in Python. Its native support for asynchronous programming, dependency injection, and background tasks makes it a powerful tool for scalable backend development. However, structuring a FastAPI project that cleanly integrates background processing, database access, and dependency injection can be challenging as your application grows.

In this article, we'll explore a practical, scalable project structure for FastAPI that balances maintainability, testability, and performance. We'll cover how to organize your code, manage database connections, implement background tasks, and leverage dependency injection effectively.

---

## Table of Contents

- [Project Structure Overview](#project-structure-overview)  
- [Database Access with Dependency Injection](#database-access-with-dependency-injection)  
- [Background Tasks in FastAPI](#background-tasks-in-fastapi)  
- [Putting It All Together: A Sample Project](#putting-it-all-together-a-sample-project)  
- [Common Pitfalls](#common-pitfalls)  
- [Best Practices](#best-practices)  
- [Conclusion](#conclusion)  

---

## Project Structure Overview

A scalable FastAPI project should separate concerns clearly and allow components to evolve independently. Here’s a typical directory layout that works well for medium to large projects:

```
app/
├── api/
│   ├── v1/
│   │   ├── endpoints/
│   │   │   ├── users.py
│   │   │   └── items.py
│   │   └── __init__.py
│   └── __init__.py
├── core/
│   ├── config.py
│   ├── security.py
│   └── __init__.py
├── db/
│   ├── base.py
│   ├── session.py
│   ├── models/
│   │   ├── user.py
│   │   └── item.py
│   └── __init__.py
├── services/
│   ├── user_service.py
│   └── background_tasks.py
├── main.py
└── __init__.py
```

### Explanation:

- **api/**: Contains route definitions grouped by API version and resource.
- **core/**: Core application settings, security utilities, and global configurations.
- **db/**: Database models, session management, and base classes.
- **services/**: Business logic and background task implementations.
- **main.py**: Application entrypoint where FastAPI app is created and configured.

This modular structure helps isolate responsibilities and makes it easier to scale and maintain the codebase.

---

## Database Access with Dependency Injection

FastAPI’s dependency injection system is ideal for managing database sessions in a clean, testable way.

### Setting Up SQLAlchemy Session

First, create a database session factory in `db/session.py`:

```python
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"  # Replace with your DB URL

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}  # SQLite specific
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db() -> Session:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

### Using Dependency Injection in Routes

Inject the database session into your API endpoints:

```python
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.models.user import User

router = APIRouter()

@router.get("/users/{user_id}")
def read_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user
```

### Benefits

- **Scoped sessions**: Each request gets its own DB session.
- **Easy testing**: You can override `get_db` dependency with mocks.
- **Clean resource management**: Sessions are closed automatically.

---

## Background Tasks in FastAPI

Background tasks are essential for offloading long-running or non-blocking operations such as sending emails, processing files, or updating caches.

### Using FastAPI’s BackgroundTasks

FastAPI provides a simple `BackgroundTasks` utility that runs tasks after returning a response:

```python
from fastapi import BackgroundTasks, APIRouter

router = APIRouter()

def send_welcome_email(email: str):
    # Simulate sending email
    print(f"Sending welcome email to {email}")

@router.post("/users/")
def create_user(email: str, background_tasks: BackgroundTasks):
    # Create user logic here
    background_tasks.add_task(send_welcome_email, email)
    return {"message": "User created"}
```

### When to Use More Robust Task Queues

For more complex or heavy background processing, consider integrating task queues like **Celery**, **RQ**, or **Dramatiq**. These allow:

- Distributed task execution
- Retry mechanisms
- Monitoring and scheduling

You can still trigger these tasks from FastAPI endpoints using dependency injection and service layers.

---

## Putting It All Together: A Sample Project

Let's combine these concepts into a minimal but scalable example.

### 1. Define Models (`db/models/user.py`)

```python
from sqlalchemy import Column, Integer, String
from app.db.base import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
```

### 2. Create Base and Engine (`db/base.py`)

```python
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
```

### 3. Service Layer with Background Task (`services/user_service.py`)

```python
from sqlalchemy.orm import Session
from app.db.models.user import User

def create_user(db: Session, email: str) -> User:
    user = User(email=email)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

def send_welcome_email(email: str):
    # Placeholder for real email sending logic
    print(f"Sending welcome email to {email}")
```

### 4. API Endpoint (`api/v1/endpoints/users.py`)

```python
from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.services import user_service

router = APIRouter()

@router.post("/users/")
def create_user(
    email: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    user = user_service.create_user(db, email)
    background_tasks.add_task(user_service.send_welcome_email, email)
    return user
```

### 5. Application Entry (`main.py`)

```python
from fastapi import FastAPI
from app.api.v1.endpoints import users
from app.db import base, session
import uvicorn

app = FastAPI()

app.include_router(users.router, prefix="/api/v1")

# Create tables on startup (for demo purposes)
@app.on_event("startup")
def on_startup():
    base.Base.metadata.create_all(bind=session.engine)

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
```

This example demonstrates a clean separation of concerns, dependency injection for the database session, and background task execution.

---

## Common Pitfalls

- **Long-running tasks in request thread**: Avoid executing heavy tasks synchronously in the request lifecycle; always offload to background tasks or external workers.
- **Improper session management**: Not closing DB sessions can lead to connection leaks. Always use dependency injection with proper cleanup.
- **Mixing business logic in routes**: Keep your API endpoints thin by delegating business logic to service layers.
- **Global state or singletons for DB sessions**: Never use a global session instance; always create scoped sessions per request.
- **Ignoring async compatibility**: Mixing sync and async code improperly can cause performance issues or deadlocks.

---

## Best Practices

- **Use Dependency Injection Everywhere**: Leverage FastAPI’s DI system for database sessions, configuration, and services to improve testability.
- **Isolate Background Tasks**: Keep background task logic in separate service modules to maintain separation of concerns.
- **Use Alembic for Migrations**: Manage your database schema changes with Alembic instead of creating tables programmatically.
- **Write Tests for Services**: Test your business logic independently of the API layer by mocking dependencies.
- **Configure Logging and Monitoring**: Integrate structured logging and monitoring early to track background tasks and DB performance.
- **Consider Async DB Drivers**: For fully async apps, use async-compatible ORMs or drivers like `encode/databases` or `SQLAlchemy 1.4+` async support.

---

## Conclusion

Building scalable FastAPI applications requires thoughtful project structure and leveraging FastAPI’s powerful features like dependency injection and background tasks. By cleanly separating your API, database access, and business logic layers, and managing resources properly, you set a solid foundation for maintainable and performant backend services.

Start simple, keep your components modular, and evolve your architecture as your application grows. With these patterns, you’ll be well-equipped to build robust FastAPI backends that scale gracefully.