SilentGPT Dev Engine – FastAPI Backend Pack #1

Dieses ZIP enthält alle Artikel dieses Packs als Markdown-Dateien
sowie die JSON-Definition des Packs.

Du kannst die Dateien z.B. in deinem eigenen Wissens- oder Doku-System
weiterverwenden.
